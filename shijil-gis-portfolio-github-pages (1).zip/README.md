# Shijil TC — Environmental GIS & Remote Sensing Portfolio

This is a GitHub Pages-ready version of the portfolio.

## Publish with GitHub Pages

1. Create a GitHub repository, for example `gis-portfolio`.
2. Upload **all files and folders inside this package**.
3. In GitHub, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`.
6. Save. GitHub will provide the public website URL.

## Important: assets

The supplied HTML references an `assets/` folder containing images and the MSc dissertation PDF. Those files were not included with the uploaded HTML, so they must be copied into this package before publishing.

Referenced assets include:

- `assets/Shijil_TC_MSc_Dissertation_LST_Kerala_2025.pdf`
- `assets/Flood Map - rp00005.png`
- `assets/LULC.jpeg`
- `assets/11.png`
- `assets/GEE_Paddy_Detection_LatestSCL.png`
- `assets/GEE_Supervised_LULC_Classification.png`
- `assets/GEE_NSSI_Assessment.png`

Keep the filenames exactly as referenced by `index.html`, or update the paths in the HTML.

## Result

Once published, the site will be accessible publicly through a URL similar to:

`https://YOUR-GITHUB-USERNAME.github.io/gis-portfolio/`
